# 🛡️ PhishGuard

A free phishing link checker — works as a website (iPhone friendly!) and as a Chrome/Firefox browser extension.

**Live site:** https://YOUR-USERNAME.github.io/phishguard

---

## 🚀 Deploy to GitHub Pages (5 minutes)

### Step 1 — Create the repo
1. Go to [github.com/new](https://github.com/new)
2. Name it `phishguard`
3. Set it to **Public**
4. Click **Create repository**

### Step 2 — Upload files
1. On your new repo page, click **"uploading an existing file"**
2. Drag and drop ALL files from this folder (including the `extension/` subfolder)
3. Click **Commit changes**

### Step 3 — Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages**
2. Under "Source", select **Deploy from a branch**
3. Choose branch: **main**, folder: **/ (root)**
4. Click **Save**

### Step 4 — Done!
After ~60 seconds your site will be live at:
`https://YOUR-USERNAME.github.io/phishguard`

---

## 📁 File structure

```
phishguard/
├── index.html              ← The website
├── README.md               ← This file
└── extension/
    ├── manifest.json
    ├── background.js
    ├── content.js
    ├── phish-guard.zip     ← Downloadable by visitors
    ├── popup/
    └── icons/
```
