// PhishGuard - Background Service Worker
// Checks URLs against Google Safe Browsing API + heuristic checks

const SAFE_BROWSING_API_KEY = "YOUR_API_KEY_HERE"; // Replace with your Google Safe Browsing API key
const SAFE_BROWSING_URL = "https://safebrowsing.googleapis.com/v4/threatMatches:find";

// Tab state: tracks safety status per tab
const tabState = {};

// ─── Heuristic Phishing Detection ───────────────────────────────────────────

const SUSPICIOUS_KEYWORDS = [
  "login", "signin", "verify", "account", "secure", "update", "banking",
  "paypal", "amazon", "apple", "google", "microsoft", "netflix", "ebay",
  "password", "credential", "wallet", "confirm", "suspend", "unusual"
];

const TRUSTED_DOMAINS = new Set([
  "google.com", "youtube.com", "facebook.com", "amazon.com", "apple.com",
  "microsoft.com", "github.com", "wikipedia.org", "twitter.com", "x.com",
  "instagram.com", "linkedin.com", "reddit.com", "netflix.com", "paypal.com",
  "ebay.com", "bankofamerica.com", "chase.com", "wellsfargo.com"
]);

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function heuristicCheck(url) {
  const warnings = [];
  let riskScore = 0;

  try {
    const parsed = new URL(url);
    const domain = parsed.hostname;
    const fullUrl = url.toLowerCase();

    // Check for IP address as host
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(domain)) {
      warnings.push("Uses an IP address instead of a domain name");
      riskScore += 40;
    }

    // Excessive subdomains
    const parts = domain.split(".");
    if (parts.length > 4) {
      warnings.push("Unusually many subdomains");
      riskScore += 20;
    }

    // Long domain name
    if (domain.length > 40) {
      warnings.push("Unusually long domain name");
      riskScore += 15;
    }

    // Suspicious TLDs
    const suspiciousTLDs = [".xyz", ".top", ".club", ".work", ".live", ".online", ".site", ".tk", ".ml", ".ga", ".cf"];
    if (suspiciousTLDs.some(tld => domain.endsWith(tld))) {
      warnings.push("Uses a high-risk top-level domain");
      riskScore += 25;
    }

    // Brand name in subdomain (typosquatting)
    const baseDomain = parts.slice(-2).join(".");
    for (const trusted of TRUSTED_DOMAINS) {
      const trustedName = trusted.split(".")[0];
      if (domain.includes(trustedName) && !domain.endsWith(trusted)) {
        warnings.push(`Mimics a trusted brand (${trusted}) but is a different domain`);
        riskScore += 50;
        break;
      }
    }

    // Suspicious keywords in URL
    const matchedKeywords = SUSPICIOUS_KEYWORDS.filter(k => fullUrl.includes(k));
    if (matchedKeywords.length >= 2) {
      warnings.push(`Contains suspicious keywords: ${matchedKeywords.slice(0, 3).join(", ")}`);
      riskScore += 20;
    }

    // HTTP (not HTTPS) for sensitive-looking pages
    if (parsed.protocol === "http:" && matchedKeywords.length > 0) {
      warnings.push("Not using HTTPS on a sensitive-looking page");
      riskScore += 30;
    }

    // Lots of hyphens in domain
    const hyphenCount = (domain.match(/-/g) || []).length;
    if (hyphenCount >= 3) {
      warnings.push("Domain contains many hyphens (common in fake sites)");
      riskScore += 20;
    }

    // URL encoding tricks
    if (fullUrl.includes("%2f") || fullUrl.includes("%40") || fullUrl.includes("@")) {
      warnings.push("URL contains encoding tricks that may disguise the true destination");
      riskScore += 35;
    }

  } catch (e) {
    warnings.push("Could not parse URL");
    riskScore += 10;
  }

  return { riskScore, warnings };
}

// ─── Google Safe Browsing API ────────────────────────────────────────────────

async function checkSafeBrowsing(url) {
  if (SAFE_BROWSING_API_KEY === "YOUR_API_KEY_HERE") {
    return { threat: false, type: null }; // Skip if no key configured
  }

  try {
    const response = await fetch(`${SAFE_BROWSING_URL}?key=${SAFE_BROWSING_API_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client: { clientId: "phishguard", clientVersion: "1.0.0" },
        threatInfo: {
          threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
          platformTypes: ["ANY_PLATFORM"],
          threatEntryTypes: ["URL"],
          threatEntries: [{ url }]
        }
      })
    });

    const data = await response.json();
    if (data.matches && data.matches.length > 0) {
      return { threat: true, type: data.matches[0].threatType };
    }
  } catch (e) {
    console.warn("Safe Browsing API error:", e);
  }

  return { threat: false, type: null };
}

// ─── Combined URL Analysis ───────────────────────────────────────────────────

async function analyzeUrl(url) {
  // Skip browser internal pages
  if (!url || url.startsWith("chrome://") || url.startsWith("about:") || url.startsWith("moz-extension://") || url.startsWith("chrome-extension://")) {
    return { status: "safe", riskScore: 0, warnings: [], sbThreat: false };
  }

  const domain = extractDomain(url);

  // Immediately trust well-known domains
  if (domain && TRUSTED_DOMAINS.has(domain)) {
    return { status: "safe", riskScore: 0, warnings: [], sbThreat: false };
  }

  const [heuristics, safeBrowsing] = await Promise.all([
    Promise.resolve(heuristicCheck(url)),
    checkSafeBrowsing(url)
  ]);

  let { riskScore, warnings } = heuristics;

  if (safeBrowsing.threat) {
    riskScore += 100;
    warnings.unshift(`⚠️ Google Safe Browsing flagged this as: ${safeBrowsing.threat.replace(/_/g, " ")}`);
  }

  let status;
  if (riskScore >= 60 || safeBrowsing.threat) {
    status = "danger";
  } else if (riskScore >= 25) {
    status = "warning";
  } else {
    status = "safe";
  }

  return { status, riskScore, warnings, sbThreat: safeBrowsing.threat };
}

// ─── Icon Management ─────────────────────────────────────────────────────────

function setIcon(tabId, status) {
  const icons = {
    safe:    { "16": "icons/icon16.png",    "32": "icons/icon32.png"    },
    warning: { "16": "icons/icon16_warn.png","32": "icons/icon32_warn.png"},
    danger:  { "16": "icons/icon16_danger.png","32": "icons/icon32_danger.png"},
    checking:{ "16": "icons/icon16.png",    "32": "icons/icon32.png"    }
  };

  const titles = {
    safe: "PhishGuard – This page looks safe",
    warning: "PhishGuard – Suspicious page detected!",
    danger: "PhishGuard – DANGER: Likely phishing!",
    checking: "PhishGuard – Checking..."
  };

  chrome.action.setIcon({ tabId, path: icons[status] || icons.safe });
  chrome.action.setTitle({ tabId, title: titles[status] || titles.safe });
  chrome.action.setBadgeText({ tabId, text: status === "danger" ? "!" : status === "warning" ? "?" : "" });
  chrome.action.setBadgeBackgroundColor({ tabId, color: status === "danger" ? "#e53e3e" : "#f6ad55" });
}

// ─── Navigation Listener ─────────────────────────────────────────────────────

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return; // Main frame only

  const { tabId, url } = details;

  setIcon(tabId, "checking");

  const result = await analyzeUrl(url);
  tabState[tabId] = { url, ...result, timestamp: Date.now() };

  setIcon(tabId, result.status);

  // If dangerous, inject warning overlay into the page
  if (result.status === "danger") {
    chrome.tabs.sendMessage(tabId, {
      type: "SHOW_WARNING",
      data: { url, ...result }
    }).catch(() => {}); // Content script may not be ready yet; it will re-check on load
  }
});

// Store result for content scripts that request it
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_TAB_STATE") {
    const tabId = sender.tab?.id;
    sendResponse(tabState[tabId] || null);
    return true;
  }

  if (msg.type === "ANALYZE_URL") {
    analyzeUrl(msg.url).then(sendResponse);
    return true;
  }

  if (msg.type === "GET_CURRENT_TAB_STATE") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (tab) {
        sendResponse(tabState[tab.id] || { status: "safe", warnings: [], riskScore: 0, url: tab.url });
      } else {
        sendResponse(null);
      }
    });
    return true;
  }
});

// Clean up old tab state
chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabState[tabId];
});
