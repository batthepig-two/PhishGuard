// PhishGuard - Content Script
// Injects warning overlays for dangerous/suspicious pages

let warningShown = false;

function showWarningOverlay(data) {
  if (warningShown) return;
  warningShown = true;

  const isDanger = data.status === "danger";
  const accentColor = isDanger ? "#e53e3e" : "#dd6b20";
  const bgColor = isDanger ? "#1a0505" : "#1a0f00";
  const borderColor = isDanger ? "#fc8181" : "#f6ad55";

  const overlay = document.createElement("div");
  overlay.id = "phishguard-overlay";
  overlay.style.cssText = `
    all: initial;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    background: ${bgColor}ee !important;
    z-index: 2147483647 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    font-family: 'Segoe UI', system-ui, sans-serif !important;
    backdrop-filter: blur(8px) !important;
  `;

  const warningList = (data.warnings || [])
    .map(w => `<li style="margin: 6px 0; color: #fed7d7; font-size: 14px; line-height: 1.5;">${w}</li>`)
    .join("");

  overlay.innerHTML = `
    <div style="
      all: initial;
      display: block;
      background: #1a1a2e;
      border: 2px solid ${borderColor};
      border-radius: 16px;
      padding: 40px;
      max-width: 520px;
      width: 90vw;
      box-shadow: 0 0 60px ${accentColor}44, 0 20px 60px #00000088;
      font-family: 'Segoe UI', system-ui, sans-serif;
      text-align: center;
      box-sizing: border-box;
    ">
      <div style="font-size: 64px; margin-bottom: 16px;">${isDanger ? "🚨" : "⚠️"}</div>

      <div style="
        display: inline-block;
        background: ${accentColor}22;
        border: 1px solid ${accentColor};
        color: ${borderColor};
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 3px;
        text-transform: uppercase;
        padding: 4px 14px;
        border-radius: 100px;
        margin-bottom: 16px;
      ">PhishGuard${isDanger ? " · Danger Detected" : " · Warning"}</div>

      <h1 style="
        all: initial;
        display: block;
        color: #fff;
        font-size: 24px;
        font-weight: 800;
        margin: 0 0 12px 0;
        font-family: 'Segoe UI', system-ui, sans-serif;
        line-height: 1.3;
      ">${isDanger ? "This site may be trying to steal your information!" : "This site looks suspicious"}</h1>

      <p style="
        all: initial;
        display: block;
        color: #a0aec0;
        font-size: 14px;
        margin: 0 0 24px 0;
        font-family: 'Segoe UI', system-ui, sans-serif;
        line-height: 1.6;
        word-break: break-all;
      ">
        <span style="color: #718096;">URL: </span>
        <span style="color: ${borderColor};">${(data.url || "").substring(0, 80)}${data.url?.length > 80 ? "…" : ""}</span>
      </p>

      ${data.warnings?.length ? `
        <div style="
          background: #ffffff08;
          border: 1px solid #ffffff15;
          border-radius: 10px;
          padding: 16px 20px;
          margin-bottom: 28px;
          text-align: left;
        ">
          <div style="color: #a0aec0; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px;">Why we flagged this:</div>
          <ul style="all:initial; display:block; list-style: none; padding: 0; margin: 0;">
            ${warningList}
          </ul>
        </div>
      ` : ""}

      <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
        <button id="phishguard-back" style="
          all: initial;
          display: inline-block;
          background: ${accentColor};
          color: #fff;
          font-size: 15px;
          font-weight: 700;
          padding: 12px 28px;
          border-radius: 10px;
          cursor: pointer;
          font-family: 'Segoe UI', system-ui, sans-serif;
          box-shadow: 0 4px 20px ${accentColor}66;
          transition: opacity 0.2s;
        ">← Go Back to Safety</button>

        <button id="phishguard-proceed" style="
          all: initial;
          display: inline-block;
          background: transparent;
          color: #718096;
          font-size: 13px;
          font-weight: 500;
          padding: 12px 20px;
          border-radius: 10px;
          cursor: pointer;
          font-family: 'Segoe UI', system-ui, sans-serif;
          border: 1px solid #2d3748;
        ">I understand the risk, proceed anyway</button>
      </div>

      <p style="
        all: initial;
        display: block;
        color: #4a5568;
        font-size: 11px;
        margin-top: 20px;
        font-family: 'Segoe UI', system-ui, sans-serif;
      ">Protected by PhishGuard · Risk score: ${data.riskScore}/100</p>
    </div>
  `;

  document.documentElement.appendChild(overlay);

  document.getElementById("phishguard-back").addEventListener("click", () => {
    history.back();
    setTimeout(() => { window.close(); }, 300);
  });

  document.getElementById("phishguard-proceed").addEventListener("click", () => {
    overlay.remove();
    warningShown = false;
  });
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SHOW_WARNING") {
    showWarningOverlay(msg.data);
  }
});

// Also check on page load (catches cases where content script loads after navigation event)
window.addEventListener("DOMContentLoaded", () => {
  chrome.runtime.sendMessage({ type: "GET_TAB_STATE" }, (response) => {
    if (response && (response.status === "danger") && !warningShown) {
      showWarningOverlay(response);
    }
  });
});
