# 🛡️ PhishGuard — Browser Extension

A real-time phishing link detector for Chrome and Firefox. Shows a **color-coded toolbar icon** and **full-page warning overlay** when you visit suspicious or dangerous sites.

---

## ✨ Features

- 🔴 **Red icon + full-page block** for likely phishing/malware sites
- 🟡 **Yellow icon + risk score** for suspicious sites
- 🟢 **Green icon** for safe pages
- **Heuristic detection** — catches phishing tricks like typosquatting, IP addresses, suspicious TLDs, fake brand names, and more
- **Google Safe Browsing API** support (optional, free API key required)
- Works on **all websites** automatically

---

## 🚀 Installation (Chrome / Edge)

1. Open Chrome and go to: `chrome://extensions`
2. Enable **Developer Mode** (toggle in the top right)
3. Click **"Load unpacked"**
4. Select the `phish-guard` folder
5. The PhishGuard shield icon will appear in your toolbar ✅

### Firefox
1. Go to: `about:debugging#/runtime/this-firefox`
2. Click **"Load Temporary Add-on"**
3. Select the `manifest.json` file inside the `phish-guard` folder

---

## 🔑 Optional: Google Safe Browsing API

For even better detection, add a free Google Safe Browsing API key:

1. Go to: https://developers.google.com/safe-browsing/v4/get-started
2. Create a project and enable the Safe Browsing API
3. Generate an API key
4. Open `background.js` and replace:
   ```
   const SAFE_BROWSING_API_KEY = "YOUR_API_KEY_HERE";
   ```
   with your actual key.
5. Reload the extension in `chrome://extensions`

---

## 🧠 How It Works

PhishGuard runs two checks on every page you visit:

### 1. Heuristic Analysis (always on)
Checks for red flags like:
- IP address used instead of domain name
- Brand name impersonation (e.g. `paypal-secure.xyz`)
- Suspicious TLDs (`.xyz`, `.tk`, `.ml`, etc.)
- Excessive hyphens in domain
- URL encoding tricks (`%40`, `@` in URL)
- HTTP on sensitive-looking pages
- Many subdomains

### 2. Google Safe Browsing (optional)
Checks against Google's database of known malware/phishing URLs.

---

## 📁 File Structure

```
phish-guard/
├── manifest.json       # Extension config
├── background.js       # URL analysis + icon management
├── content.js          # Warning overlay injected into pages
├── popup/
│   ├── popup.html      # Toolbar popup UI
│   └── popup.js        # Popup logic
└── icons/              # Extension icons (normal/warning/danger)
```

---

## ⚠️ Limitations

- Heuristic detection may have occasional false positives on legitimate but unusual URLs
- Without a Safe Browsing API key, only heuristic checks run
- Very new phishing sites may not yet be in Safe Browsing databases

---

Made with ❤️ by PhishGuard
