// PhishGuard Popup Script

const statusConfig = {
  safe: {
    icon: "✅",
    label: "Safe",
    message: "This page looks safe to browse.",
    riskColor: "#38a169"
  },
  warning: {
    icon: "⚠️",
    label: "Warning",
    message: "This page has suspicious characteristics.",
    riskColor: "#dd6b20"
  },
  danger: {
    icon: "🚨",
    label: "Danger",
    message: "This site may be trying to steal your data!",
    riskColor: "#e53e3e"
  }
};

function renderStatus(state) {
  const config = statusConfig[state.status] || statusConfig.safe;
  const riskPct = Math.min(100, state.riskScore || 0);
  const url = state.url || "";
  const shortUrl = url.length > 50 ? url.substring(0, 50) + "…" : url;

  const warningsHtml = (state.warnings || []).length > 0 ? `
    <div class="warnings-list">
      <div class="warnings-title">Why we flagged this</div>
      ${state.warnings.slice(0, 4).map(w => `
        <div class="warning-item">${w}</div>
      `).join("")}
    </div>
  ` : "";

  document.getElementById("content").innerHTML = `
    <div class="status-section">
      <div class="status-card ${state.status}">
        <div class="status-top">
          <div class="status-icon">${config.icon}</div>
          <div>
            <div class="status-label ${state.status}">${config.label}</div>
            <div class="status-message">${config.message}</div>
          </div>
        </div>
        <div class="url-display">${shortUrl}</div>
        <div class="risk-meter">
          <div class="risk-label">
            <span>Risk Score</span>
            <span>${riskPct}/100</span>
          </div>
          <div class="risk-bar">
            <div class="risk-fill" style="width: ${riskPct}%; background: ${config.riskColor};"></div>
          </div>
        </div>
      </div>
    </div>
    ${warningsHtml}
  `;
}

// Load state from background
chrome.runtime.sendMessage({ type: "GET_CURRENT_TAB_STATE" }, (state) => {
  if (chrome.runtime.lastError) {
    document.getElementById("content").innerHTML = `
      <div class="loading">Could not connect to PhishGuard.</div>
    `;
    return;
  }

  if (state) {
    renderStatus(state);
  } else {
    // Analyze current tab URL directly
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url;
      if (url) {
        chrome.runtime.sendMessage({ type: "ANALYZE_URL", url }, (result) => {
          renderStatus({ ...result, url });
        });
      }
    });
  }
});

document.getElementById("settings-btn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage?.() || alert("Settings coming soon!");
});
